import { useState } from "react";
import { ethers } from "ethers";

export default function WalletBalance() {
  const [account, setAccount] = useState("");
  const [balance, setBalance] = useState("");

  const connectWallet = async () => {
    if (!window.ethereum) {
      alert("Please install MetaMask");
      return;
    }

    const provider = new ethers.BrowserProvider(window.ethereum);
    await provider.send("eth_requestAccounts", []);
    
    const signer = await provider.getSigner();
    const address = await signer.getAddress();
    setAccount(address);

    // Get Balance
    const bal = await provider.getBalance(address);
    const ethBalance = ethers.formatEther(bal);

    setBalance(ethBalance);
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Wallet Balance Checker</h2>

      <button onClick={connectWallet}>
        {account ? "Connected" : "Connect Wallet"}
      </button>

      <p><strong>Address:</strong> {account}</p>
      <p><strong>Balance:</strong> {balance} ETH</p>
    </div>
  );
}